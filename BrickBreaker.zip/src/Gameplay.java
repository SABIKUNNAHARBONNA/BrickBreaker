import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Gameplay extends JPanel implements KeyListener, ActionListener{
	private boolean play = false;
	private int score = 0;
	
	private int[] totalBricks = {21, 32, 45};
	
	private Timer timer;
	private int delay = 4;
	private int level = 0;
	private boolean active = false;
        private boolean popUp = true;
        private int popUpTime = 0;
        
	private int playerX = 310;
	
	private int ballPosX = 350;
	private int ballPosY = 530;
	private int ballXdir = -1;
	private int ballYdir = -2;
	
	private ArrayList<MapGenerator> map;
	
	public Gameplay() {
		map = new ArrayList<MapGenerator>(3);
		map.add(new MapGenerator(3, 7));
		map.add(new MapGenerator(4, 8));
		map.add(new MapGenerator(5, 9));
		this.addKeyListener(this);
		this.setFocusable(true);
		this.setFocusTraversalKeysEnabled(false);
		timer = new Timer(delay,this);
		timer.start();
		
	}
	
	public void paint(Graphics g) {
		//background
		g.setColor(Color.BLACK);
		g.fillRect(1, 1, 692, 592);
		
		//drawing map
		map.get(level).draw((Graphics2D)g);
		
		//borders
		g.setColor(Color.YELLOW);
		g.fillRect(0, 0, 3, 592);
		g.fillRect(0, 0, 692, 3);
		g.fillRect(691, 0, 3, 592);
		
		//score
		g.setColor(Color.WHITE);
		g.setFont(new Font("serif", Font.BOLD, 25));
		g.drawString("Score:"+score, 580, 30);
		
		//paddle
		g.setColor(Color.GREEN);
		g.fillRect(playerX, 550, 100, 8);
		
		//ball
		g.setColor(Color.YELLOW);
		g.fillOval(ballPosX, ballPosY, 20, 20);
		
		if(totalBricks[level] <= 0) {
			level++;
                        popUp = true;
			play = false;
			playerX = 310;
			ballPosX = 350;
			ballPosY = 530;
			ballXdir = -1;
			ballYdir = -2;
	
		}
		
		if(totalBricks[2] <= 0) {
			play = false;
                        popUp = false;
			ballXdir = 0;
			ballYdir = 0;
			active = true;
			g.setColor(Color.RED);
			g.setFont(new Font("serif", Font.BOLD, 30));
			g.drawString("You Won", 230, 300);
			
			g.setFont(new Font("serif", Font.BOLD, 20));
			g.drawString("Press enter to Restart", 230, 350);
		}
		if(ballPosY > 570) {
			play = false;
			ballXdir = 0;
			ballYdir = 0;
			active = true;
			g.setColor(Color.RED);
			g.setFont(new Font("serif", Font.BOLD, 30));
			g.drawString("Game Over, Score: "+score, 190, 300);
			
			g.setFont(new Font("serif", Font.BOLD, 20));
			g.drawString("Press enter to Restart", 230, 350);
			
		}
                if(popUp){
                    g.setColor(Color.RED);
                    g.fillRect(0, 240, 700, 120);
                    g.setColor(Color.WHITE);
                    g.fillRect(0, 250, 700, 100);
                    g.setColor(Color.BLACK);
                    g.setFont(new Font("serif",Font.BOLD,50));
                    g.drawString("Level - "+(level+1),255,315);
                }
		
		g.dispose();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		timer.start();
                if(popUp) {
                    popUpTime++;
                    if(popUpTime>400){
                        popUp = false;
                        popUpTime = 0;
                    }
                }
		if(play) {
			if(new Rectangle(ballPosX, ballPosY, 20, 20).intersects(new Rectangle(playerX,550,100,8))) {
				ballYdir = -ballYdir;
			}
			
			A: for(int i = 0; i < map.get(level).map.length; i++) {
				for(int j = 0; j < map.get(level).map[i].length; j++) {
					if(map.get(level).map[i][j] > 0) {
						int brickX = j * map.get(level).brickWidth + 80;
						int brickY = i * map.get(level).brickHeight + 50;
						int brickWidth = map.get(level).brickWidth;
						int brickHeight = map.get(level).brickHeight;
						
						Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
						Rectangle ballRect = new Rectangle(ballPosX, ballPosY, 20,20);
						Rectangle brickRect = rect;
						
						if(ballRect.intersects(brickRect)) {
							map.get(level).setBrickValue(0, i, j);
							totalBricks[level]--;
							score += 5;
							
							if(ballPosX + 19 <= brickRect.x || ballPosX + 1 >= brickRect.x + brickRect.width) {
								ballXdir = -ballXdir;
							}else {
								ballYdir = -ballYdir;
							}
							break A;
						}
					}
				}
			}
			ballPosX += ballXdir;
			ballPosY += ballYdir;
			if(ballPosX < 0) {
				ballXdir = -ballXdir;
			}
			if(ballPosY < 0) {
				ballYdir = -ballYdir;
			}
			if(ballPosX > 670) {
				ballXdir = -ballXdir;
			}
		}
		
		repaint();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {}
	@Override
	public void keyReleased(KeyEvent e) {}


	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT && !popUp) {
			if(playerX >= 600) {
				playerX = 600;
			}else {
				moveRight();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT && !popUp ) {
			if(playerX < 10) {
				playerX = 10;
			}else {
				moveLeft();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_ENTER && active) {
			popUp = true;
			playerX = 310;
			ballPosX = 350;
			ballPosY = 530;
			ballXdir = -1;
			ballYdir = -2;
			score = 0;
			level = 0;
			active = false;
			totalBricks[0] = 21;
			totalBricks[1] = 32;
			totalBricks[2] = 45;
			map.clear();
			map.add(new MapGenerator(3, 7));
			map.add(new MapGenerator(4, 8));
			map.add(new MapGenerator(5, 9));
			repaint();
		}
	}
	public void moveRight() {
		play = true;
		playerX+=20;
	}
	public void moveLeft() {
		play = true;
		playerX-=20;
	}

}


